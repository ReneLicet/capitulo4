﻿using Cibertec.Repositories.Northwind;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cibertec.UnitOfWork
{
    public interface IUnitOfWork
    {
        ICustomerRepository Customers { get; }
        IOrderItemRepository OrderItem { get; }
        IOrderRepository Order { get; }
        IProductRepository Product { get; }
        ISupplierRepository Supplier { get; }
    }
}
